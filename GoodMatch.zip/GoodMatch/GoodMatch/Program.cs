﻿using System;
using System.Collections.Generic;
using System.IO;
using CsvHelper;
using System.Globalization;
using System.Linq;

//Author: Nokwanda Mchunu
namespace GoodMatch
{
    class Program
    {
        static void Main(string[] args)
        {
            //Read data from CSV file to the female and male set
            HashSet<string> females = new HashSet<string>();
            HashSet<string> males = new HashSet<string>();
            Console.WriteLine("Reading from csv file.....");
            using (var streamreader = new StreamReader("..\\file.csv"))
            {
                while (!streamreader.EndOfStream)
                {
                    var line = streamreader.ReadLine();
                    //Console.WriteLine(line);
                    var values = line.Split(',');
                    if (values[1].Equals("f"))
                    {
                        females.Add(values[0]);
                    }
                    else if (values[1].Equals("m"))
                    {
                        males.Add(values[0]);
                    }
                }
            }
            Console.WriteLine();
            Dictionary<string, int> resultValuePair = new Dictionary<string, int>();
            Console.WriteLine("females......");
            List<string> femaleList = females.ToList();
            for(int i=0; i<femaleList.Count; i++)
            {
                Console.WriteLine(femaleList[i]);
            }
            Console.WriteLine();
            Console.WriteLine("males......");
            List<string> maleList = males.ToList();
            for (int i = 0; i < maleList.Count; i++)
            {
                Console.WriteLine(maleList[i]);
            }
            //match every female with every male
            for (int x=0; x<femaleList.Count; x++)
            {
                for(int y=0; y<maleList.Count; y++)
                {
                    string curFemale = femaleList[x];
                    string curMale = maleList[y];
                    Object[] resArray= matchValue(curFemale, curMale);
                    resultValuePair.Add((string)resArray[0], (int)resArray[1]);
                }
            }
            //Sort results by percentage descending then first name ascending 
            var myList = resultValuePair.ToList();
            myList = myList.OrderBy(x => x.Key).ToList();
            myList.Sort((pair1, pair2) => pair2.Value.CompareTo(pair1.Value));
            foreach (var value in myList)
            {
                //Console.WriteLine(value);
                //Write results to textfile 
                using (StreamWriter streamWriter = File.AppendText("Data.txt"))
                {
                    streamWriter.WriteLine(value.Key);

                }
            }
        }

        //Take as input two string 
        //Return Object array
        public static Object[] matchValue(string name1, string name2)
        {
            Console.WriteLine();
            string sentence = name1 + " matches " + name2;
            Console.WriteLine(sentence);

            Dictionary<char, int> valuePairs = new Dictionary<char, int>();

            for (int x = 0; x < sentence.Length; x++)
            {
                char curChar = sentence[x];
                if (curChar == ' ')
                {
                    continue;
                }
                if (valuePairs.ContainsKey(curChar))
                {
                    valuePairs[curChar] += 1;
                }
                else
                {
                    valuePairs.Add(curChar, 1);
                }
            }

            List<int> numberOfOcc = new List<int>();
            numberOfOcc.AddRange(valuePairs.Values);
            string list = "";
            for (int i = 0; i < numberOfOcc.Count; i++)
            {
                list += numberOfOcc[i];
                Console.Write(numberOfOcc[i]);
            }
            Console.WriteLine();

            string results = getResult(list);
            Console.WriteLine(results);
            //Print result 
            int res = int.Parse(results);
            Object[] resultArray = new object[2];
                if (res >= 80)
                {
                    
                    resultArray[0] = name1+" matches "+name2+" " +res+"% good match";
                    resultArray[1] = res;
                    
                }
                else
                {
                   
                    resultArray[0] = name1 + " matches " + name2 + " " + res + "% ";
                    resultArray[1] = res;
                    
                }
            return resultArray;

        }

        public static string getResult(string list)
        {
            if (list.Length == 0)
            {
                return null;
            }
            if (list.Length == 2)
            {
                return list;
            }
            string result = "";
            int tempSum = 0;
            while (list.Length >= 2)
            {
                int firstInt = int.Parse(list[0].ToString());
                int secondInt = int.Parse(list[list.Length-1].ToString());
                tempSum = firstInt + secondInt;
                result += tempSum;
                list = list.Remove(0,1);
                list =list.Remove(list.Length - 1);
            }
            if(list.Length ==1)
            {
                int curValue = int.Parse(list[0].ToString());
                result += curValue;
            }

            return getResult(result);
        }
    }
}
